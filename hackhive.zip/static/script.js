const form = document.getElementById("transactionForm");
const message = document.getElementById("message");

const currency = value =>
    Number(value).toLocaleString("en-IN", {
        style: "currency",
        currency: "INR"
    });

async function loadDashboard() {
    const response = await fetch("/api/dashboard");

    if (!response.ok) {
        throw new Error("Could not load dashboard");
    }

    const data = await response.json();

    document.getElementById("revenue").textContent =
        currency(data.total_revenue);

    document.getElementById("expenses").textContent =
        currency(data.total_expenses);

    document.getElementById("savings").textContent =
        currency(data.savings);
}

async function loadTransactions() {
    const response = await fetch("/api/transactions");

    if (!response.ok) {
        throw new Error("Could not load transactions");
    }

    const transactions = await response.json();
    const tbody = document.getElementById("transactions");

    tbody.replaceChildren();

    if (transactions.length === 0) {
        const row = tbody.insertRow();
        const cell = row.insertCell();
        cell.colSpan = 5;
        cell.textContent = "No transactions added yet.";
        return;
    }

    transactions.forEach(item => {
        const row = tbody.insertRow();

        [
            item.transaction_date,
            item.type,
            item.category,
            currency(item.amount),
            item.description || "-"
        ].forEach(value => {
            const cell = row.insertCell();
            cell.textContent = value;
        });
    });
}

async function refreshDashboard() {
    try {
        await Promise.all([
            loadDashboard(),
            loadTransactions()
        ]);
    } catch (error) {
        message.textContent =
            "Unable to load data. Check Flask and MySQL.";
    }
}

form.addEventListener("submit", async function (event) {
    event.preventDefault();

    const transaction = {
        type: document.getElementById("type").value,
        amount: document.getElementById("amount").value,
        category: document.getElementById("category").value,
        description: document.getElementById("description").value
    };

    message.textContent = "Saving transaction...";

    try {
        const response = await fetch("/api/transactions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(transaction)
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.error || "Unable to save");
        }

        message.textContent = result.message;
        form.reset();

        await refreshDashboard();
    } catch (error) {
        message.textContent = error.message;
    }
});

refreshDashboard();
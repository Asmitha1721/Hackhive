from flask import Flask, render_template, request, jsonify
import mysql.connector
from datetime import date

app = Flask(__name__)


# Connect to MySQL
def get_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="YOUR_ACTUAL_MYSQL_PASSWORD",
        database="business_db"
    )


# Display the dashboard
@app.route("/")
def home():
    return render_template("index.html")


# Get dashboard totals
@app.route("/api/dashboard", methods=["GET"])
def dashboard():
    db = get_db()
    cursor = db.cursor()

    try:
        cursor.execute("""
            SELECT
                COALESCE(SUM(
                    CASE WHEN type = 'revenue'
                    THEN amount ELSE 0 END
                ), 0),
                COALESCE(SUM(
                    CASE WHEN type = 'expense'
                    THEN amount ELSE 0 END
                ), 0)
            FROM transactions
        """)

        revenue, expenses = cursor.fetchone()
        revenue = float(revenue)
        expenses = float(expenses)
        profit = revenue - expenses

        return jsonify({
            "total_revenue": round(revenue, 2),
            "total_expenses": round(expenses, 2),
            "savings": round(profit, 2)
        })

    finally:
        cursor.close()
        db.close()


# Add a transaction
@app.route("/api/transactions", methods=["POST"])
def add_transaction():
    data = request.get_json(silent=True) or {}

    transaction_type = data.get("type")
    category = data.get("category")
    description = data.get("description", "")
    amount = data.get("amount")

    if transaction_type not in ("revenue", "expense"):
        return jsonify({"error": "Invalid transaction type"}), 400

    if not isinstance(category, str) or not category.strip():
        return jsonify({"error": "Enter a category"}), 400

    if not isinstance(description, str) or len(description) > 255:
        return jsonify({"error": "Invalid description"}), 400

    try:
        amount = float(amount)
        if not 0 < amount < 1_000_000_000_000:
            raise ValueError()
    except (TypeError, ValueError):
        return jsonify({"error": "Enter a valid positive amount"}), 400

    db = get_db()
    cursor = db.cursor()

    try:
        cursor.execute("""
            INSERT INTO transactions
            (type, amount, category, description, transaction_date)
            VALUES (%s, %s, %s, %s, %s)
        """, (
            transaction_type,
            amount,
            category.strip(),
            description.strip(),
            date.today()
        ))

        db.commit()

        return jsonify({
            "message": "Transaction added successfully"
        }), 201

    except mysql.connector.Error:
        db.rollback()
        return jsonify({"error": "Database error while saving"}), 500

    finally:
        cursor.close()
        db.close()


# Get transaction history
@app.route("/api/transactions", methods=["GET"])
def get_transactions():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    try:
        cursor.execute("""
            SELECT id, type, amount, category,
                   description, transaction_date
            FROM transactions
            ORDER BY id DESC
        """)

        rows = cursor.fetchall()

        for row in rows:
            row["amount"] = float(row["amount"])
            row["transaction_date"] = str(row["transaction_date"])

        return jsonify(rows)

    finally:
        cursor.close()
        db.close()


if __name__ == "__main__":
    app.run(debug=True)
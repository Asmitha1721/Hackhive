// Format numbers as Indian Rupees
function formatRupees(amount) {
    return new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 2
    }).format(amount);
}

// Update financial dashboard
document.getElementById("financeForm").addEventListener(
    "submit",
    function (event) {

        event.preventDefault();

        const revenue = Number(
            document.getElementById("newRevenue").value
        );

        const expenses = Number(
            document.getElementById("newExpenses").value
        );

        const cashflow = Number(
            document.getElementById("newCashflow").value
        );

        if (
            !Number.isFinite(revenue) ||
            !Number.isFinite(expenses) ||
            !Number.isFinite(cashflow) ||
            revenue < 0 ||
            expenses < 0
        ) {
            document.getElementById("message").textContent =
                "Please enter valid financial values.";
            return;
        }

        // Calculate net profit
        const profit = revenue - expenses;

        // Display updated values
        document.getElementById("revenue").textContent =
            formatRupees(revenue);

        document.getElementById("expenses").textContent =
            formatRupees(expenses);

        document.getElementById("profit").textContent =
            formatRupees(profit);

        document.getElementById("cashflow").textContent =
            formatRupees(cashflow);

        // Display success message
        document.getElementById("message").textContent =
            "Dashboard updated successfully!";

        // Clear the form
        document.getElementById("financeForm").reset();
    }
);

// Submission button
function showSubmission() {
    alert(
        "HackHive - Maceco Analytics\n\n" +
        "Your project dashboard is ready for review."
    );
}